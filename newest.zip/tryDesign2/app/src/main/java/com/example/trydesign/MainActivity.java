package com.example.trydesign;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {


    BottomNavigationView bottomNavigationView;

    CalandarFragment calandarFragment = new CalandarFragment();
    GardenFragment gardenFragment = new GardenFragment();
    HomeFragment homeFragment = new HomeFragment();
    ShopFragment shopFragment = new ShopFragment();
    StatisticsFragment statisticsFragment = new StatisticsFragment();

    // creating variables for our edittext, button and dbhandler
 //   private EditText courseNameEdt, courseTracksEdt, courseDurationEdt, courseDescriptionEdt;
   // private Button addCourseBtn;
    public static DBHandler dbHandler;
    Context context = getApplicationContext();
    DBHandler dbHandlerr = new DBHandler(context);







    public void loadItemsFromDatabase(){
        //this method should read the database
        ArrayList<ShopItemDetails> items = new ArrayList<>();

        SQLiteDatabase db = dbHandler.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + DBHandler.TABLE_NAME,  new String[]{});
        while(cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            int price = cursor.getInt(2);
            String description = cursor.getString(3);
            String imageID = cursor.getString(4);
            int amount = cursor.getInt(5);
            ShopItemDetails item = new ShopItemDetails(name, imageID, price, description, amount);
            items.add(item);
        }
        // Define a projection that specifies which columns from the database
// you will actually use after this query.
        String[] projection = {
                BaseColumns._ID,
                DBHandler.DB_NAME,
                DBHandler.DESCRIPTION_COL,
                DBHandler.IMG_COL,
                DBHandler.NAME_COL,
                DBHandler.PRICE_COL
        };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ShopItemDetails.init();
        dbHandlerr.doesYaaTableExist();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing all our variables.
//        courseNameEdt = findViewById(R.id.idEditPlantName);
//        courseTracksEdt = findViewById(R.id.idEdtCourseTracks);
//        courseDurationEdt = findViewById(R.id.idEdtCourseDuration);
//        courseDescriptionEdt = findViewById(R.id.idEdtCourseDescription);
//        addCourseBtn = findViewById(R.id.idBtnAddCourse);

        // creating a new dbhandler class
        // and passing our context to it.
        SQLiteDatabase d = MainActivity.dbHandler.getWritableDatabase();


//        // below line is to add on click listener for our add course button.
//        addCourseBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {

//                // below line is to get data from all edit text fields.
//                String courseName = courseNameEdt.getText().toString();
//                String courseTracks = courseTracksEdt.getText().toString();
//                String courseDuration = courseDurationEdt.getText().toString();
//                String courseDescription = courseDescriptionEdt.getText().toString();

//                // validating if the text fields are empty or not.
//                if (courseName.isEmpty() && courseTracks.isEmpty() && courseDuration.isEmpty() && courseDescription.isEmpty()) {
//                    Toast.makeText(MainActivity.this, "Please enter all the data..", Toast.LENGTH_SHORT).show();
//                    return;
//                }


        //me tryingtings
        String plantName = "";
        int plantPrice = 1;
        String plantDescription = "";
        String plantImg = "";

        // on below line we are calling a method to add new
        // plant to sqlite data and pass all our values to it.
        dbHandler.addNewPlant(plantName, plantPrice, plantDescription, plantImg, 0);


//                // after adding the data we are displaying a toast message.
//                Toast.makeText(MainActivity.this, "Course has been added.", Toast.LENGTH_SHORT).show();
//                courseNameEdt.setText("");
//                courseDurationEdt.setText("");
//                courseTracksEdt.setText("");
//                courseDescriptionEdt.setText("");
//            }


        setContentView(R.layout.activity_main);
        //navigation-ing**********************
        bottomNavigationView = findViewById(R.id.bottom_navigation);


        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.homeId:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, homeFragment).commit();
                    return true;
                case R.id.shopId:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, shopFragment).commit();
                    return true;
                case R.id.gardenId:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, gardenFragment).commit();
                    return true;
                case R.id.calandarId:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, calandarFragment).commit();
                    return true;
                case R.id.statisticsId:
                    getSupportFragmentManager().beginTransaction().replace(R.id.container, statisticsFragment).commit();
                    return true;
            }

            return false;
        });

//


    }
}