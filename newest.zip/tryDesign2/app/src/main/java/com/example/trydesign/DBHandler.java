package com.example.trydesign;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import android.content.ContentValues;
import android.util.Log;

public class DBHandler extends SQLiteOpenHelper {

    // creating a constant variables for our database.
    // below variable is for our database name.
    public static final String DB_NAME = "Shop Database";

    // below int is our database version
    public static final int DB_VERSION = 1;

    // below variable is for our table name.
    public static final String TABLE_NAME = "plants";

    // below variable is for our id column.
    public static final String ID_COL = "id";

    // below variable is for our plant name column
    public static final String NAME_COL = "name";

    // below variable id for our plant duration column.
    public static final String PRICE_COL = "price";

    // below variable for our plant description column.
    public static final String DESCRIPTION_COL = "description";

    // below variable is for our plant tracks column.
    public static final String IMG_COL = "imagelink";
    public static final String AMOUNT_COL = "amount";

    // creating a constructor for our database handler.
    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // below method is for creating a database by running a sqlite query
    @Override
    public void onCreate(SQLiteDatabase db) {
        // on below line we are creating
        // an sqlite query and we are
        // setting our column names
        // along with their data types.
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT,"
                + PRICE_COL + " INTEGER,"
                + DESCRIPTION_COL + " TEXT,"
                + IMG_COL + " TEXT,"
                + AMOUNT_COL + " INTEGER DEFAULT 0)";

        // at last we are calling a exec sql
        // method to execute above sql query
        db.execSQL(query);
        Log.e("onatejfgvkjsdbCre: ", "onatejfgvkjsdbCre: ");
    }

    // this method is use to add new plant to our sqlite database.
    public void addNewPlant(String plantName, int plantPrice, String plantDescription, String plantImg, int plantAmount) {

        // on below line we are creating a variable for
        // our sqlite database and calling writable method
        // as we are writing data in our database.
        SQLiteDatabase db = this.getWritableDatabase();

        // on below line we are creating a
        // variable for content values.
        ContentValues values = new ContentValues();

        // on below line we are passing all values
        // along with its key and value pair.
        values.put(NAME_COL, plantName);
        values.put(PRICE_COL, plantPrice);
        values.put(DESCRIPTION_COL, plantDescription);
        values.put(IMG_COL, plantImg);
        values.put(AMOUNT_COL, plantAmount);

        // after adding all values we are passing
        // content values to our table.
        db.insert(TABLE_NAME, null, values);

        // at last we are closing our
        // database after adding database.
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // this method is called to check if the table exists already.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }


    public void doesYaaTableExist(){
        SQLiteDatabase db = this.getWritableDatabase();

        //cewhcking if the table already esists
        Cursor cursorr = db.rawQuery("SELECT name " +
                        "FROM sqlite_master " +
                        "WHERE type='table' " +
                        "AND name='" +
                        TABLE_NAME + "'",
                null);
        //table not exist so need to create one
        if (cursorr.getCount() == 0){
            //create ya tabel bitch
            String query = "CREATE TABLE " + TABLE_NAME + " ("
                    + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + NAME_COL + " TEXT,"
                    + PRICE_COL + " INTEGER,"
                    + DESCRIPTION_COL + " TEXT,"
                    + IMG_COL + " TEXT,"
                    + AMOUNT_COL + " INTEGER DEFAULT 0)";
            db.execSQL(query);
            //to store all the shop item details in it#
            for (int i = 0; i<ShopItemDetails.items.size(); i++){
                ContentValues values = new ContentValues();
                values.put(ID_COL, ShopItemDetails.items.get(i).itemID);
                values.put(NAME_COL, ShopItemDetails.items.get(i).itemName);
                values.put(PRICE_COL, ShopItemDetails.items.get(i).itemPrice);
                values.put(DESCRIPTION_COL, ShopItemDetails.items.get(i).itemDescription);
                values.put(IMG_COL, ShopItemDetails.items.get(i).imageID);
                values.put(AMOUNT_COL, ShopItemDetails.items.get(i).itemAmount);
                db.insert(TABLE_NAME, null, values);
            }
        }
        else{
            //query ya tablke bitch
            //using a readable databse cause thr table already exxists so dont want to accidentally make any changes to it
            SQLiteDatabase datab = this.getReadableDatabase();
            String query = "SELECT * FROM "+TABLE_NAME;
            Cursor cursor = datab.rawQuery(query, null);
            //twill loop through till there is no more where ot put the cursor so has looked at the wholeeee table
            while (cursor.moveToNext()) {
                int id = cursor.getInt(0);
                String name = cursor.getString(1);
                int price = cursor.getInt(2);
                String description = cursor.getString(3);
                String image = cursor.getString(4);
                Integer amount = cursor.getInt(5);

                ShopItemDetails item = ShopItemDetails.findItemById(id);
                item.itemName = name;
                item.itemPrice = price;
                item.itemDescription = description;
                item.imageID = image;
                item.itemAmount = amount;


            }
        }
        db.endTransaction();
        db.close();





        //one of the errors you will write about is forgetting these lines of code:
//    cursor.close();
//    db.close();

    }
}
