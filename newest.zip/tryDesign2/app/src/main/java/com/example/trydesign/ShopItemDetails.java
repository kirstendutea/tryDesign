package com.example.trydesign;

import java.util.ArrayList;

public class ShopItemDetails {
    public static ArrayList<ShopItemDetails> items = new ArrayList<>();
    public int itemID;
    public String imageID;
    public String itemName;
    public String itemDescription;
    public int itemPrice;
    public int itemAmount;
    public static int idCounter = 0;    //getters
    public int getId() {
        return itemID;
    }
    public String getName() {
        return itemName;
    }
    public String getImageID() {
        return imageID;
    }
    public String getDescription() {
        return itemDescription;
    }
    public int getPrice() {
        return itemPrice;
    }

    //setters
    public void setId(int itemID){
        this.itemID = itemID;
    }
    public void setName(String itemName){
        this.itemName = itemName;
    }
    public void setImageID(String imageID){
        this.imageID = imageID;
    }
    public void setDescription(String itemDescription){
        this.itemDescription = itemDescription;
    }
    public void setPrice(int price){
        this.itemPrice = itemPrice;
    }

    public ShopItemDetails(String itemName, String imageID, int itemPrice, String itemDescription, int itemAmount) {
        this.itemName = itemName;
        this.imageID = imageID;
        this.itemPrice = itemPrice;
        this.itemDescription = itemDescription;
        this.itemAmount = itemAmount;
        this.itemID = idCounter++;
    }



    public static void init() {
        // Add items to the list
        items.add(new ShopItemDetails("popp0", "res/drawable/poppy.jpg", 0, "a popp0", 0));
        items.add(new ShopItemDetails("popp1", "res/drawable/poppy.jpg", 10, "a popp1", 10));
        items.add(new ShopItemDetails("popp2", "res/drawable/poppy.jpg", 20, "a popp2", 20));
        items.add(new ShopItemDetails("popp3", "res/drawable/poppy.jpg", 30, "a popp3", 30));
    }


    public static ShopItemDetails findItemById(int id) {
        for (int i = 0; i < ShopItemDetails.items.size(); i++) {
            if (items.get(i).itemID == id){
                return items.get(i);
            }
        }

        return null;
    }
}