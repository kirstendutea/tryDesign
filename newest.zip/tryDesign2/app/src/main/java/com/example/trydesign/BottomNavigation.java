package com.example.trydesign;

import android.app.Activity;

public class BottomNavigation extends Activity {
}
