package com.example.trydesign;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class ShopFragment extends Fragment {
    private View ShopItem1;
    private View ShopItem2;
    private View ShopItem3;
    private View ShopItem4;

    public static ArrayList<ShopItemDetails> items = new ArrayList<>();
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        items.add(new ShopItemDetails("poppy","res/drawable/poppy.jpg", 100, "its a poppy",0 ));
        items.add(new ShopItemDetails("poppy1","res/drawable/poppy.jpg", 110, "its a poppy1",0 ));
        items.add(new ShopItemDetails("poppy2","res/drawable/poppy.jpg", 120, "its a poppy2",0 ));
        items.add(new ShopItemDetails("poppy3","res/drawable/poppy.jpg", 130, "its a poppy3",0 ));
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_shop, container, false);
        ShopItem1 = view.findViewById(R.id.ShopItem1);
        ShopItem2 = view.findViewById(R.id.ShopItem2);
        ShopItem3 = view.findViewById(R.id.ShopItem3);
        ShopItem4 = view.findViewById(R.id.ShopItem4);


        ShopItem1.setOnClickListener(this::onClick);
        ShopItem2.setOnClickListener(this::onClick);
        ShopItem3.setOnClickListener(this::onClick);
        ShopItem4.setOnClickListener(this::onClick);

        return view;
    }//oh

    public void onClick(View v){
        ShopItemDetails itemDetailsID = null;

        if (v.getId() == R.id.ShopItem1){
            itemDetailsID = items.get(0);
        }
        if (v.getId() == R.id.ShopItem2){
            itemDetailsID = items.get(1);
        }
        if (v.getId() == R.id.ShopItem3){
            itemDetailsID = items.get(2);
        }
        if (v.getId() == R.id.ShopItem4){
            itemDetailsID = items.get(3);
        }
    }

}
