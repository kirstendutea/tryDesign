package com.example.trydesign;

import static com.example.trydesign.ShopItemDetails.items;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ShopItem#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ShopItem extends Fragment {

    private Button buyButton;
    private int itemDetailsID;

    public ShopItem() {
        // Required empty public constructor
    }
    public static ShopItemDetails findItemById(int id) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).itemID == id){
                return items.get(i);
            }
        }
        return null;
    }


    public static ShopItem newInstance(int itemDetailsID) {
        ShopItem fragment = new ShopItem();
        Bundle args = new Bundle();
        args.putInt("itemDetailsID", itemDetailsID);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            //to get the details related to the id
            itemDetailsID = getArguments().getInt("itemDetailsID");
            //gets DhopITemDetails and passes this to the ShopItem fragment
            ShopItemDetails itemDetails = findItemById(itemDetailsID);

            //setting the fields for said item
            ImageView itemImage = getView().findViewById(R.id.item_image);
            int imgSrcint = Integer.parseInt(itemDetails.imageID);
            itemImage.setImageResource(imgSrcint);

            TextView itemName = getView().findViewById(R.id.item_name);
            itemName.setText((CharSequence) itemDetails.itemName);

            TextView itemDescription = getView().findViewById(R.id.item_description);
            itemDescription.setText((CharSequence) itemDetails.itemDescription);

            TextView itemPrice = getView().findViewById(R.id.item_price);
            itemPrice.setText(String.valueOf(itemDetails.itemPrice));

            TextView itemAmount = getView().findViewById(R.id.item_amount);
            itemAmount.setText(String.valueOf(itemDetails.itemAmount));

        }
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        View view = inflater.inflate(R.layout.fragment_shop, container);
        LinearLayout ShopItemLayout = view.findViewById(R.id.shopitemsgohere);


        return view;
    }



}